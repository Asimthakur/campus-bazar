# Campus Bazar

A full-stack Django marketplace for college students to buy and sell items
on campus, with college-email-gated signup and a REST API.

Built to back this resume bullet set:
- Full-stack Django app with RESTful backend APIs
- College-email-based authentication that blocks non-campus signups
- Optimized SQL queries / ORM usage (select_related, indexes) for fast,
  scalable reads
- Modular backend: separate `accounts` (auth/profile) and `marketplace`
  (listings/messages/favorites) apps

## Stack

Python 3, Django 6, Django REST Framework, django-filter, SQLite (swap for
Postgres in production), server-rendered HTML templates (no JS framework
required).

## Project layout

```
campus_bazar/
├── campus_bazar/        # project settings, root urls
├── accounts/             # custom signup, email verification, profile
├── marketplace/           # listings, categories, messages, favorites, API
│   └── management/commands/seed_demo_data.py
├── templates/             # base.html + accounts/ + marketplace/
├── static/css/style.css
├── requirements.txt
└── manage.py
```

## 1. Local setup

```bash
# from inside campus_bazar/
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

python3 manage.py migrate
python3 manage.py createsuperuser
python3 manage.py seed_demo_data   # optional: adds 6 categories + 8 sample listings
python3 manage.py runserver
```

Visit:
- `http://127.0.0.1:8000/` — the marketplace
- `http://127.0.0.1:8000/admin/` — Django admin
- `http://127.0.0.1:8000/api/listings/` — browsable REST API

## 2. Configure your real college domain

Edit `ALLOWED_EMAIL_DOMAINS` in `campus_bazar/settings.py` (or set the
`ALLOWED_EMAIL_DOMAINS` env var, comma-separated) to your actual college
domain(s), e.g. `jkie.ac.in`. Signups with any other email domain are
rejected at the form level (`accounts/forms.py: clean_college_email`).

## 3. How the resume claims map to code

| Resume claim | Where it lives |
|---|---|
| College-email auth, ~90% fewer fraudulent accounts | `accounts/forms.py` (domain check) + `accounts/views.py` (account stays `is_active=False` until the emailed link is clicked) |
| RESTful backend APIs | `marketplace/api_views.py`, `marketplace/serializers.py`, routed in `campus_bazar/urls.py` via DRF's `DefaultRouter` |
| Optimized SQL queries / ORM tuning | `select_related()` on every list/detail view to avoid N+1 queries (see `marketplace/views.py`, `api_views.py`); composite DB indexes on `Listing.status/created_at/category/price` in `marketplace/models.py` |
| Scalable, modular data models | Two decoupled apps (`accounts`, `marketplace`), normalized models (`Category`, `Listing`, `Message`, `Favorite`) |

Be ready to talk through these honestly in an interview — e.g. you can
explain *why* `select_related` avoids N+1 queries and *why* those specific
indexes were chosen, rather than just citing a number. That's what
actually gets tested when an interviewer asks "walk me through your
project."

## 4. Email verification in dev

`EMAIL_BACKEND` is set to Django's console backend, so verification emails
print straight to your terminal instead of needing a real mail server.
Sign up, copy the verification link from the terminal output, and paste it
into your browser to activate the account.

For a real deployment, switch to an SMTP backend (e.g. Gmail SMTP,
SendGrid, AWS SES) by setting `DJANGO_EMAIL_BACKEND` and the relevant SMTP
env vars.

## 5. REST API quick reference

```
GET    /api/listings/                       list (paginated, filterable)
GET    /api/listings/?category__slug=books-notes
GET    /api/listings/?search=cycle
GET    /api/listings/?ordering=price
POST   /api/listings/                       create (auth required)
PATCH  /api/listings/{id}/                  update (owner only)
DELETE /api/listings/{id}/                  delete (owner only)
GET    /api/categories/
GET    /api/messages/                       your inbox/sent threads
POST   /api/messages/
GET    /api/favorites/
POST   /api/token/                          {username, password} -> auth token
```

Auth: either log in via the browsable API (session auth) or POST to
`/api/token/` and send `Authorization: Token <token>` on subsequent
requests.

## 6. Suggested next steps before you demo this

1. Run it locally, click through: sign up → verify email → post a listing
   → search/filter → message a seller → mark as sold.
2. Push to GitHub with a clear README (this file) and a few screenshots.
3. Deploy a live demo (Railway, Render, or PythonAnywhere all have free
   tiers that work well for a Django + SQLite/Postgres app) so you have a
   link to drop in your resume/portfolio next to the GitHub repo.
4. Swap SQLite for Postgres before deploying anywhere persistent — SQLite
   is fine for a local demo but isn't meant for concurrent production
   writes.
