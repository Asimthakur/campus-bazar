from django.contrib.auth.views import LogoutView
from django.urls import path

from . import views

app_name = 'accounts'

urlpatterns = [
    path('signup/', views.SignUpView.as_view(), name='signup'),
    path('login/', views.CampusLoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('verify/<uidb64>/<token>/', views.verify_email, name='verify_email'),
    path('profile/edit/', views.profile_edit, name='profile_edit'),
]
