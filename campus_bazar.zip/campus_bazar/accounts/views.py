from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.views import LoginView
from django.core.mail import send_mail
from django.shortcuts import redirect, render
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.views.generic import CreateView

from .forms import ProfileEditForm, SignUpForm
from .models import Profile
from .tokens import email_verification_token


def _send_verification_email(request, user):
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = email_verification_token.make_token(user)
    verify_path = reverse('accounts:verify_email', kwargs={'uidb64': uid, 'token': token})
    verify_url = request.build_absolute_uri(verify_path)
    subject = "Verify your Campus Bazar account"
    body = render_to_string('accounts/email_verification.txt', {
        'user': user, 'verify_url': verify_url,
    })
    send_mail(subject, body, settings.DEFAULT_FROM_EMAIL, [user.profile.college_email])


class SignUpView(CreateView):
    form_class = SignUpForm
    template_name = 'accounts/signup.html'

    def form_valid(self, form):
        user = form.save(commit=False)
        # College-email-gated accounts start inactive until verified.
        user.is_active = False
        user.email = form.cleaned_data['college_email']
        user.save()
        Profile.objects.create(
            user=user,
            college_email=form.cleaned_data['college_email'],
            branch=form.cleaned_data.get('branch', ''),
            year=form.cleaned_data.get('year') or None,
            phone=form.cleaned_data.get('phone', ''),
        )
        _send_verification_email(self.request, user)
        messages.success(
            self.request,
            "Account created! Check the console / your inbox for a verification link "
            "before logging in."
        )
        return redirect('accounts:login')


def verify_email(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and email_verification_token.check_token(user, token):
        user.is_active = True
        user.save()
        user.profile.is_verified = True
        user.profile.save()
        login(request, user)
        messages.success(request, "Email verified! Welcome to Campus Bazar.")
        return redirect('marketplace:home')

    messages.error(request, "That verification link is invalid or has expired.")
    return redirect('accounts:login')


class CampusLoginView(LoginView):
    template_name = 'accounts/login.html'


@login_required
def profile_edit(request):
    profile = request.user.profile
    if request.method == 'POST':
        form = ProfileEditForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated.")
            return redirect('marketplace:my_listings')
    else:
        form = ProfileEditForm(instance=profile)
    return render(request, 'accounts/profile_edit.html', {'form': form})
