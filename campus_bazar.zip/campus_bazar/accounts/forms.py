from django import forms
from django.conf import settings
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Profile


class SignUpForm(UserCreationForm):
    college_email = forms.EmailField(
        help_text="Use your official college email address (e.g. you@jkie.ac.in)."
    )
    branch = forms.CharField(max_length=100, required=False)
    year = forms.ChoiceField(choices=Profile.YEAR_CHOICES, required=False)
    phone = forms.CharField(max_length=15, required=False)

    class Meta:
        model = User
        fields = ['username', 'email', 'college_email', 'branch', 'year', 'phone', 'password1', 'password2']

    def clean_college_email(self):
        email = self.cleaned_data['college_email'].lower().strip()
        domain = email.split('@')[-1] if '@' in email else ''
        if domain not in settings.ALLOWED_EMAIL_DOMAINS:
            allowed = ", ".join(settings.ALLOWED_EMAIL_DOMAINS)
            raise forms.ValidationError(
                f"Only college email domains are allowed ({allowed})."
            )
        if Profile.objects.filter(college_email=email).exists():
            raise forms.ValidationError("This college email is already registered.")
        return email


class ProfileEditForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['branch', 'year', 'phone', 'hostel_or_address', 'avatar']
