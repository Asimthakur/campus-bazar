from django.contrib import admin

from .models import Profile


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'college_email', 'is_verified', 'branch', 'year', 'created_at']
    list_filter = ['is_verified', 'branch', 'year']
    search_fields = ['user__username', 'college_email']
