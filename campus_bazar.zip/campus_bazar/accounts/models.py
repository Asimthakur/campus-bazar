from django.conf import settings
from django.db import models


class Profile(models.Model):
    """
    Extends Django's built-in User with campus-specific fields.
    is_verified flips to True only after the user clicks the emailed
    verification link, which is what backs the "reduced fraudulent
    accounts" claim -- only real college-email holders ever go active.
    """
    YEAR_CHOICES = [
        (1, '1st Year'), (2, '2nd Year'), (3, '3rd Year'), (4, '4th Year'),
    ]

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile')
    college_email = models.EmailField(unique=True)
    is_verified = models.BooleanField(default=False)
    branch = models.CharField(max_length=100, blank=True)
    year = models.PositiveSmallIntegerField(choices=YEAR_CHOICES, null=True, blank=True)
    phone = models.CharField(max_length=15, blank=True)
    hostel_or_address = models.CharField(max_length=150, blank=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} ({self.college_email})"
