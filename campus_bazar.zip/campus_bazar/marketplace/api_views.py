from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters, permissions, viewsets

from .models import Category, Favorite, Listing, Message
from .permissions import IsOwnerOrReadOnly
from .serializers import (
    CategorySerializer, FavoriteSerializer, ListingSerializer, MessageSerializer,
)


class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [permissions.AllowAny]


class ListingViewSet(viewsets.ModelViewSet):
    """
    RESTful CRUD for listings.

    Supports:
      GET  /api/listings/?category=electronics&status=active&search=cycle&ordering=price
      POST /api/listings/                (auth required)
      PATCH/DELETE /api/listings/{id}/   (owner only)
    """
    serializer_class = ListingSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsOwnerOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['category__slug', 'status', 'condition']
    search_fields = ['title', 'description']
    ordering_fields = ['price', 'created_at', 'views_count']

    def get_queryset(self):
        # select_related keeps this endpoint's query count constant
        # regardless of result size -- the core of the perf claim.
        return Listing.objects.select_related('seller', 'category').all()


class MessageViewSet(viewsets.ModelViewSet):
    serializer_class = MessageSerializer
    permission_classes = [permissions.IsAuthenticated, IsOwnerOrReadOnly]

    def get_queryset(self):
        user = self.request.user
        from django.db.models import Q
        return (
            Message.objects.filter(Q(sender=user) | Q(receiver=user))
            .select_related('sender', 'receiver', 'listing')
        )


class FavoriteViewSet(viewsets.ModelViewSet):
    serializer_class = FavoriteSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Favorite.objects.filter(user=self.request.user).select_related('listing')
