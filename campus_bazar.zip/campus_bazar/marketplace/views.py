from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render

from .forms import ListingForm, MessageForm
from .models import Category, Favorite, Listing, Message


def home(request):
    # select_related pulls seller+category in the same query instead of
    # N extra queries per row -- this is the ORM optimization the resume
    # bullet is talking about.
    listings = Listing.objects.filter(status='active').select_related('seller', 'category')

    query = request.GET.get('q', '').strip()
    category_slug = request.GET.get('category', '')
    min_price = request.GET.get('min_price', '')
    max_price = request.GET.get('max_price', '')

    if query:
        listings = listings.filter(Q(title__icontains=query) | Q(description__icontains=query))
    if category_slug:
        listings = listings.filter(category__slug=category_slug)
    if min_price:
        listings = listings.filter(price__gte=min_price)
    if max_price:
        listings = listings.filter(price__lte=max_price)

    paginator = Paginator(listings, 12)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'marketplace/home.html', {
        'page_obj': page_obj,
        'query': query,
        'selected_category': category_slug,
        'min_price': min_price,
        'max_price': max_price,
    })


def listing_detail(request, slug):
    listing = get_object_or_404(
        Listing.objects.select_related('seller', 'seller__profile', 'category'), slug=slug
    )
    # Cheap view counter -- fine at this scale; swap for a signal/cache at higher traffic.
    Listing.objects.filter(pk=listing.pk).update(views_count=listing.views_count + 1)

    is_favorited = (
        request.user.is_authenticated
        and Favorite.objects.filter(user=request.user, listing=listing).exists()
    )

    message_form = MessageForm()
    thread = []
    if request.user.is_authenticated:
        thread = Message.objects.filter(
            listing=listing
        ).filter(
            Q(sender=request.user) | Q(receiver=request.user)
        ).select_related('sender', 'receiver')

    return render(request, 'marketplace/listing_detail.html', {
        'listing': listing,
        'is_favorited': is_favorited,
        'message_form': message_form,
        'thread': thread,
    })


@login_required
def listing_create(request):
    if request.method == 'POST':
        form = ListingForm(request.POST, request.FILES)
        if form.is_valid():
            listing = form.save(commit=False)
            listing.seller = request.user
            listing.save()
            messages.success(request, "Listing posted!")
            return redirect('marketplace:listing_detail', slug=listing.slug)
    else:
        form = ListingForm()
    return render(request, 'marketplace/listing_form.html', {'form': form, 'mode': 'create'})


@login_required
def listing_edit(request, slug):
    listing = get_object_or_404(Listing, slug=slug, seller=request.user)
    if request.method == 'POST':
        form = ListingForm(request.POST, request.FILES, instance=listing)
        if form.is_valid():
            form.save()
            messages.success(request, "Listing updated.")
            return redirect('marketplace:listing_detail', slug=listing.slug)
    else:
        form = ListingForm(instance=listing)
    return render(request, 'marketplace/listing_form.html', {'form': form, 'mode': 'edit', 'listing': listing})


@login_required
def listing_mark_sold(request, slug):
    listing = get_object_or_404(Listing, slug=slug, seller=request.user)
    listing.status = 'sold'
    listing.save(update_fields=['status'])
    messages.success(request, "Marked as sold.")
    return redirect('marketplace:listing_detail', slug=listing.slug)


@login_required
def listing_delete(request, slug):
    listing = get_object_or_404(Listing, slug=slug, seller=request.user)
    if request.method == 'POST':
        listing.delete()
        messages.success(request, "Listing removed.")
        return redirect('marketplace:my_listings')
    return render(request, 'marketplace/listing_confirm_delete.html', {'listing': listing})


@login_required
def my_listings(request):
    listings = Listing.objects.filter(seller=request.user).select_related('category')
    return render(request, 'marketplace/my_listings.html', {'listings': listings})


@login_required
def my_favorites(request):
    favorites = Favorite.objects.filter(user=request.user).select_related('listing', 'listing__category')
    return render(request, 'marketplace/my_favorites.html', {'favorites': favorites})


@login_required
def toggle_favorite(request, slug):
    listing = get_object_or_404(Listing, slug=slug)
    fav, created = Favorite.objects.get_or_create(user=request.user, listing=listing)
    if not created:
        fav.delete()
    return redirect('marketplace:listing_detail', slug=listing.slug)


@login_required
def send_message(request, slug):
    listing = get_object_or_404(Listing, slug=slug)
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            msg = form.save(commit=False)
            msg.listing = listing
            msg.sender = request.user
            msg.receiver = listing.seller
            msg.save()
    return redirect('marketplace:listing_detail', slug=listing.slug)


@login_required
def inbox(request):
    threads = (
        Message.objects.filter(Q(sender=request.user) | Q(receiver=request.user))
        .select_related('listing', 'sender', 'receiver')
        .order_by('-created_at')
    )
    return render(request, 'marketplace/inbox.html', {'threads': threads})
