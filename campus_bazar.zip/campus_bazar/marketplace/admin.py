from django.contrib import admin

from .models import Category, Favorite, Listing, Message


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']
    prepopulated_fields = {'slug': ('name',)}


@admin.register(Listing)
class ListingAdmin(admin.ModelAdmin):
    list_display = ['title', 'seller', 'category', 'price', 'status', 'views_count', 'created_at']
    list_filter = ['status', 'category', 'condition']
    search_fields = ['title', 'description', 'seller__username']
    prepopulated_fields = {'slug': ('title',)}
    # select_related avoids the N+1 query problem on the change list.
    list_select_related = ['seller', 'category']


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ['listing', 'sender', 'receiver', 'created_at', 'is_read']
    list_filter = ['is_read']


admin.site.register(Favorite)
