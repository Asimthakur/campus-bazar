from django import forms

from .models import Listing, Message


class ListingForm(forms.ModelForm):
    class Meta:
        model = Listing
        fields = ['title', 'category', 'description', 'price', 'condition', 'image']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 5}),
        }


class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ['body']
        widgets = {
            'body': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Ask the seller a question...'}),
        }
