from django.urls import path

from . import views

app_name = 'marketplace'

urlpatterns = [
    path('', views.home, name='home'),
    path('listing/new/', views.listing_create, name='listing_create'),
    path('listing/<slug:slug>/', views.listing_detail, name='listing_detail'),
    path('listing/<slug:slug>/edit/', views.listing_edit, name='listing_edit'),
    path('listing/<slug:slug>/sold/', views.listing_mark_sold, name='listing_mark_sold'),
    path('listing/<slug:slug>/delete/', views.listing_delete, name='listing_delete'),
    path('listing/<slug:slug>/favorite/', views.toggle_favorite, name='toggle_favorite'),
    path('listing/<slug:slug>/message/', views.send_message, name='send_message'),
    path('my-listings/', views.my_listings, name='my_listings'),
    path('my-favorites/', views.my_favorites, name='my_favorites'),
    path('inbox/', views.inbox, name='inbox'),
]
