from .models import Category


def categories_processor(request):
    """Makes the category list available to every template (nav bar dropdown)
    without each view having to fetch it manually."""
    return {'nav_categories': Category.objects.all()}
