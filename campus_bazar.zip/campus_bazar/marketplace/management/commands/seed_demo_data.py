import random

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

from accounts.models import Profile
from marketplace.models import Category, Listing


CATEGORIES = [
    ("Books & Notes", "books-notes", "📚"),
    ("Electronics", "electronics", "💻"),
    ("Cycles", "cycles", "🚲"),
    ("Hostel Essentials", "hostel-essentials", "🛏️"),
    ("Stationery", "stationery", "✏️"),
    ("Sports Gear", "sports-gear", "🏏"),
]

DEMO_LISTINGS = [
    ("Data Structures Textbook (3rd Edition)", "books-notes", 350, "good"),
    ("Scientific Calculator - Casio fx-991", "electronics", 600, "like_new"),
    ("Used Hero Cycle, well maintained", "cycles", 2500, "good"),
    ("Study Table Lamp", "hostel-essentials", 250, "good"),
    ("Engineering Drawing Kit (full set)", "stationery", 180, "new"),
    ("Cricket Kit Bag with bat & pads", "sports-gear", 1800, "fair"),
    ("DBMS Lab Manual + Notes Bundle", "books-notes", 150, "good"),
    ("Wired Earphones (Boat)", "electronics", 300, "like_new"),
]


class Command(BaseCommand):
    help = "Seeds demo categories, a demo seller, and sample listings for local testing."

    def handle(self, *args, **options):
        for name, slug, icon in CATEGORIES:
            Category.objects.get_or_create(slug=slug, defaults={'name': name, 'icon': icon})
        self.stdout.write(self.style.SUCCESS(f"Categories ready: {Category.objects.count()}"))

        user, created = User.objects.get_or_create(
            username='demo_seller',
            defaults={'email': 'demo.seller@jkie.ac.in', 'is_active': True},
        )
        if created:
            user.set_password('demopass123')
            user.save()
            Profile.objects.create(
                user=user, college_email='demo.seller@jkie.ac.in', is_verified=True,
                branch='CSE', year=4,
            )
            self.stdout.write(self.style.SUCCESS("Created demo_seller / demopass123"))

        for title, cat_slug, price, condition in DEMO_LISTINGS:
            category = Category.objects.get(slug=cat_slug)
            Listing.objects.get_or_create(
                title=title, seller=user,
                defaults={
                    'category': category, 'description': f"{title}. Lightly used, message me for details.",
                    'price': price, 'condition': condition,
                    'views_count': random.randint(5, 120),
                },
            )
        self.stdout.write(self.style.SUCCESS(f"Listings ready: {Listing.objects.count()}"))
