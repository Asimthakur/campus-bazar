from django.contrib.auth.models import User
from rest_framework import serializers

from .models import Category, Favorite, Listing, Message


class SellerSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username']


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'slug', 'icon']


class ListingSerializer(serializers.ModelSerializer):
    seller = SellerSerializer(read_only=True)
    category = CategorySerializer(read_only=True)
    category_id = serializers.PrimaryKeyRelatedField(
        queryset=Category.objects.all(), source='category', write_only=True
    )

    class Meta:
        model = Listing
        fields = [
            'id', 'title', 'slug', 'description', 'price', 'condition',
            'status', 'image', 'views_count', 'seller', 'category',
            'category_id', 'created_at', 'updated_at',
        ]
        read_only_fields = ['slug', 'views_count', 'seller', 'created_at', 'updated_at']

    def create(self, validated_data):
        validated_data['seller'] = self.context['request'].user
        return super().create(validated_data)


class MessageSerializer(serializers.ModelSerializer):
    sender = SellerSerializer(read_only=True)

    class Meta:
        model = Message
        fields = ['id', 'listing', 'sender', 'receiver', 'body', 'is_read', 'created_at']
        read_only_fields = ['sender', 'is_read', 'created_at']

    def create(self, validated_data):
        validated_data['sender'] = self.context['request'].user
        return super().create(validated_data)


class FavoriteSerializer(serializers.ModelSerializer):
    listing_detail = ListingSerializer(source='listing', read_only=True)

    class Meta:
        model = Favorite
        fields = ['id', 'listing', 'listing_detail', 'created_at']
        read_only_fields = ['created_at']

    def create(self, validated_data):
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)
