from rest_framework import permissions


class IsOwnerOrReadOnly(permissions.BasePermission):
    """Only the seller who created a listing can edit/delete it via the API."""

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        owner = getattr(obj, 'seller', None) or getattr(obj, 'sender', None) or getattr(obj, 'user', None)
        return owner == request.user
