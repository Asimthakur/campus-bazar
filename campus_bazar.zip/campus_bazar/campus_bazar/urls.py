from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from rest_framework import routers
from rest_framework.authtoken.views import obtain_auth_token

from marketplace.api_views import CategoryViewSet, FavoriteViewSet, ListingViewSet, MessageViewSet

router = routers.DefaultRouter()
router.register('listings', ListingViewSet, basename='listing')
router.register('categories', CategoryViewSet, basename='category')
router.register('messages', MessageViewSet, basename='message')
router.register('favorites', FavoriteViewSet, basename='favorite')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),
    path('', include('marketplace.urls')),

    # REST API
    path('api/', include(router.urls)),
    path('api/api-auth/', include('rest_framework.urls')),  # browsable API login
    path('api/token/', obtain_auth_token, name='api_token_auth'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
